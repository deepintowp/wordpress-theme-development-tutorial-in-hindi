<?php 

function subho_register_sidebar(){
	register_sidebar(array(
	
	'name'          => __( 'Left Sidebar', 'subhasish' ),
	'id'            => 'left_sidebar',
	'before_widget' => '<li id="%1$s" class="widget %2$s">',
	'after_widget'  => '</li>',
	'before_title'  => '<h1 class="widgettitle my-4">',
	'after_title'   => '</h1>' 
	
	
	) );
	
}
