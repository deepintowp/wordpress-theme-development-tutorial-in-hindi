<?php 
/*

<!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/shop-homepage.css" rel="stylesheet">

	
    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/popper/popper.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
	
	
*/



function Subho_theme_style_and_scripts(){
	//styles
	wp_register_style('bootstrap_css', THEME_URI.'/vendor/bootstrap/css/bootstrap.min.css', array(), '1.0', 'all' );
	wp_register_style('bootstrap_cdn', 'https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css', array(), '1.0', 'all' );
	wp_register_style('shophome_css', THEME_URI.'/css/shop-homepage.css', array(), '1.0', 'all' );
	wp_register_style('main_style', THEME_URI.'/style.css', array(), '1.0', 'all' );
	
	wp_enqueue_style('bootstrap_css');
	wp_enqueue_style('bootstrap_cdn');
	wp_enqueue_style('shophome_css');
	wp_enqueue_style('main_style');
	
	
	//scripts
	
	wp_register_script('popper', THEME_URI.'/vendor/popper/popper.min.js', array('jquery'), '1.0',  true );
	wp_register_script('bootstrap_js', THEME_URI.'/vendor/bootstrap/js/bootstrap.min.js', array('jquery'), '1.0',  true );
	
	wp_enqueue_script('popper');
	wp_enqueue_script('bootstrap_js');
	
	
}