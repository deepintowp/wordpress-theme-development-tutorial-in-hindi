<?php 

function subho_theme_setup(){
	add_theme_support( 'menus' );	
	
	register_nav_menus( array(
	'main_meun' => __('Main Menu', 'subhasish')
	
	) );
	
	
}
 function add_class_to_li($classes){
	 $classes[] = 'nav-item';
	 return $classes;
 }
 function add_class_to_a($attr){
	 $attr['class'] = 'nav-link';
	 return $attr;
	 
 }