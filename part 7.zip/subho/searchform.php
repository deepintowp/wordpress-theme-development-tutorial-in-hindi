<?php $qnidid = esc_attr(uniqid('subho')); ?>

<form method="get" action="<?php  echo esc_url( home_url( '/' ) ); ?> " class="navbar-form" role="search">
    <div class="input-group add-on">
      <input class="form-control" placeholder="Search" name="s" id="<?php echo $qnidid ?>" type="text">
      <div class="input-group-btn">
        <button class="btn btn-default" type="submit"><i class="glyphicon glyphicon-search"></i></button>
      </div>
    </div>
  </form>
