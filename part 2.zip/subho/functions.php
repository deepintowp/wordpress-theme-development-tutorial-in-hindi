<?php 

// Constant
define('THEME_PATH',  get_template_directory() );
define('THEME_URI',  get_template_directory_uri() );


//include
include(THEME_PATH.'/includes/front-end/enqueue.php');



//hook
add_action('wp_enqueue_scripts', 'Subho_theme_style_and_scripts');




//shortcode





