<?php 

// Constant
define('THEME_PATH',  get_template_directory() );
define('THEME_URI',  get_template_directory_uri() );


//include
include(THEME_PATH.'/includes/front-end/enqueue.php');
include(THEME_PATH.'/includes/front-end/setup.php');
include(THEME_PATH.'/includes/front-end/widget.php');



//hook
add_action('wp_enqueue_scripts', 'Subho_theme_style_and_scripts');
add_action('after_setup_theme', 'subho_theme_setup');

add_action('nav_menu_css_class', 'add_class_to_li');
add_action('nav_menu_link_attributes', 'add_class_to_a');
add_action('widgets_init', 'subho_register_sidebar');


//shortcode





show_admin_bar( false );