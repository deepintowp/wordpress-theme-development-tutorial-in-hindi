
          <!-- <h1 class="my-4">Shop Name</h1> -->
          <!-- <div class="list-group"> -->
            <!-- <a href="#" class="list-group-item">Category 1</a> -->
            <!-- <a href="#" class="list-group-item">Category 2</a> -->
            <!-- <a href="#" class="list-group-item">Category 3</a> -->
          <!-- </div> -->
		  
<?php 

if( is_active_sidebar( 'left_sidebar' )){
	dynamic_sidebar('left_sidebar' );
}
